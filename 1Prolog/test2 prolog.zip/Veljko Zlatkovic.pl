/* resenje: a za sebe ne moze da kaze da laze*/

ostrvo1(Vars) :-
	Vars[A], Vars in 0..1,
	A#<=>(#\A),
	labeling(Vars).

/* ostrvo 2

a. 
a: ja ne lažem

rešenje: ne mozemo nista da zakljucimo

prolog:


!!! NIJE MI RADIO POZIV PREDIKATA U TERMINAL TAKO DA NA DALJE NE PISE KOJA SU RESENJA " Undefined procedure"

*/

ostrvo2(Vars) :-
	Vars[A],
	A#<=>A,
	labeling(Vars).


/* ostrvo 3

a. 
a: dobar dan

rešenje:

prolog:


*/


ostrvo3(Vars) :-
	Vars[A], Vars in 0..1,
	A#<=> "dobar dan",
	labeling(Vars).
/*ostrvo 4

a, b. 
a: obojica govorimo istinu

rešenje:

prolog:

*/

ostrvo4(Vars) :-
	Vars[A,B], Vars in 0..1,
	A#<=> (A #/\ B),
	labeling(Vars).
	
	
/*
ostrvo33	
ne daje mi errore pri kompajliranju ako ista :> 
*/	

ostrvo33(Vars):-
	Vars[A, B, C, D, E, F, G, H, I, J], Vars in 0..1,
	A #<=> ( B #\= C),
	B #<=> ( #\D #<=> A),
	C #<=> ( E #<=> F),
	D #<=> ( #\B #\/ G),
	E #<=> ( A #/\ B #/\ C),
	F #<=> ( H #<=> #\I),
	G #<=> ( #\J #\/ #\A),
	H #<=> ( C #\= F),
	I #<=> ( D #/\ #\E),
	J #<=> ( #\H #\/ G),
	
	labeling(Vars).

/*ostrvo32*/

ostrvo32(Vars):-
	Vars[A, B, C, D, E, F], Vars in 0..1,
	A #<=> ( B #/\ C),
	B #<=> ( A #=> D),
	C #<=> ( #\D #\/ #\E),
	D #<=> ( A #\/ F),
	E #<=> ( B #<=> C),
	F #<=> ( E #<=> #\A),
	labeling(Vars).
	
ostrvo31(Vars):-
	Vars[A, B, C, D, E], Vars in 0..1,
	A #<=> ( B #\= C),
	B #<=> ( D #=> #\A),
	C #<=> ( E #\= C),
	D #<=> ( A + B + C #= 1),
	E #<=> ( B #<=> A),

	labeling(Vars).
	
	
ostrvo30(Vars):-
	Vars[A, B, C, D], Vars in 0..1,
	A #<=> ( B #\/ #\C),
	B #<=> ( A #=> #\D),
	C #<=> ( B #<=> C ),
	D #<=> ( #\C #/\ A),		
	labeling(Vars).
	

ostrvo27(Vars):-
	Vars[A, B, C], Vars in 0..1,
	A #<=> ( #\B #/\ #\A #/\ C),
	labeling(Vars).	
	
ostrvo26(Vars):-
	Vars[A, B, C], Vars in 0..1,
	A #<=> ( #\B #/\ #\A #/\ C),
	labeling(Vars).	
	
	ostrvo29(Vars):-
	Vars[A, B, C], Vars in 0..1,
	A #<=> ( #\B),
	C #<=> (B #\/ #\C),
	C #<=> A,
	labeling(Vars).	
	
ostrvo28(Vars):-
	Vars[A, B, C], Vars in 0..1,
	A #<=> ( B),
	C #<=> (B #\/ #\C),
	C #<=> A,
	labeling(Vars).	
	
	
