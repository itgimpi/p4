/* ostrvo 1 */

ostrvo1(Vars):-
	Vars = [A],
	Vars in 0..1,
	A #<=> (#\A),
	labeling(Vars).





/* ostrvo 2

a. 
a: ja ne lažem

rešenje:

prolog:

ostrvo2(Vars):-
	Vars = [A],
	Vars in 0..1,
	A #<=> A,
	labeling(Vars).


*/


/* ostrvo 3

a. 
a: dobar dan

rešenje:

prolog:
ostrvo3(Vars):-
	Vars = [A],
	Vars in 0..1,
	A #<=> 'Dobar dan',
	labeling(Vars).


*/


/* ostrvo 4

a, b. 
a: obojica govorimo istinu

rešenje:

prolog:

ostrvo4(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #/\ B),
	labeling(Vars).


*/

/* ostrvo 5

a, b. 
a: obojica lažemo

rešenje:

prolog:

ostrvo5(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #/\ #\B),
	labeling(Vars).


*/

/* ostrvo 6

a, b. 
a: bar 1 od nas ne laže

rešenje:

prolog:

ostrvo6(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #\/ B),
	labeling(Vars).


*/

/* ostrvo 7

a, b. 
a: bar 1 od nas laže

rešenje:

prolog:
ostrvo7(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #\/ #\B),
	labeling(Vars).


*/

/* ostrvo 8

a, b. 
a: isti smo

rešenje:

prolog:
ostrvo8(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #<=> B),
	labeling(Vars).


*/

/* ostrvo 9

a, b. 
a: nismo isti

rešenje:

prolog:
ostrvo9(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #\<=> #\B),
	labeling(Vars).


*/

/* ostrvo 10

a, b. 
a: ja govorim istinu, B govori istinu

rešenje:

prolog:
ostrvo10(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #/\ B),
	labeling(Vars).


*/

/* ostrvo 11

a, b. 
a: ja govorim istinu, B laže

rešenje:

prolog:
ostrv11(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #/\ #\B),
	labeling(Vars).


*/

/* ostrvo 12

a, b. 
a: ja lažem, B govori istinu

rešenje:

prolog:
ostrvo12(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #/\ B),
	labeling(Vars).


*/

/* ostrvo 13

a, b. 
a: ja lažem, B laže

rešenje:

prolog:
ostrvo13(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #/\ #\B),
	labeling(Vars).


*/

/* ostrvo 14

a, b. 
a: jedan od nas ne laže

rešenje:

prolog:
ostrvo14(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #\/ B),
	labeling(Vars).


*/

/* ostrvo 15

a, b. 
a: jedan od nas laže

rešenje:

prolog:
ostrvo15(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #\/ #\B),
	labeling(Vars).


*/

/* ostrvo 16

a, b. 
a: ako ja govorim istinu, B govori istinu

rešenje:

prolog:
ostrvo16(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #=> B),
	labeling(Vars).


*/

/* ostrvo 17

a, b. 
a: ako ja govorim istinu, B laže

rešenje:

prolog:
ostrvo17(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (A #=> #\B),
	labeling(Vars).


*/

/* ostrvo 18

a, b. 
a: ako ja lažem, B govori istinu

rešenje:

prolog:
ostrvo18(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #=> B),
	labeling(Vars).


*/

/* ostrvo 19

a, b. 
a: ako ja lažem, B laže

rešenje:

prolog:

ostrvo19(Vars):-
	Vars = [A,B],
	Vars in 0..1,
	A #<=> (#\A #=> #\B),
	labeling(Vars).


*/

/* ostrvo 20

a,b,c. 
a: 1 od nas istinu, 
b: svi lažemo, 
c: ostali su lažovi 

rešenje: 

prolog:

ostrvo20(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> (A #\/ B #\/ C),
	B #<=> (#\A #/\ #\B #/\ #\C),
	C #<=> (#\A #/\ #\B),
	labeling(Vars).

*/


/* ostrvo 21

a, b, c. 
a: b ne laže
b: a i c lažu

rešenje: 

prolog:
ostrvo21(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> B,
	B #<=> (#\A #/\ #\C),
	labeling(Vars).

*/

/* ostrvo 22

a, b, c. 
a: ako ja ne lažem, b laže
b: ja ne lažem, c laže

rešenje: 

prolog:
ostrvo22(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> (A => #\B),
	B #<=> (B #=> #\C),
	labeling(Vars).

*/

/* ostrvo 23

a, b, c. 
a: ja istinu, za njih ne znam
b: ako a istinu, ja lazem
c: isti sam kao a

rešenje: 

prolog:
ostrvo23(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> A ,
	B #<=> (A => #\B),
	C #<=> (C <=> A),
	labeling(Vars).

*/

/* ostrvo 24

a, b, c. 
a: dobar dan
b: taj sto je reko dobar dan je lazov
c: ma svi su oni lazovi

rešenje: 

prolog:
ostrvo24(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> A,
	B #<=> #\A,
	C #<=> (#\A #/\ #\B),
	labeling(Vars).

*/

/* ostrvo 25

a, b, c. 
a: ako ja lazem, b ne laze
b: isti sam kao c
c: a laze za razliku od mene

rešenje: 

prolog:
ostrvo25(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> (#\A #=> B),
	B #<=> (B #<=> C),
	C #<=> ((#\A #/\ C) #\/ (#A #/\ #\C)),
	labeling(Vars).

*/

/* ostrvo 26

a, b, c. 
a: b laže i ja lažem
a: c ne laže

rešenje: 

prolog:
ostrvo26(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> (#\B #/\ #\A),
	A #<=> C,
	labeling(Vars).

*/

/* ostrvo 27

a, b, c. 
a: b laže i ja lažem
a: c ne laže

rešenje:

prolog:
ostrvo27(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> (#\B #/\ #\A),
	A #<=> C,
	labeling(Vars).

*/

/* ostrvo 28

a, b, c. 
a: b ne laže
c: b ne laže ili ja lažem
c: a ne laže

rešenje: 

prolog:
ostrvo28(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> B,
	C #<=> (B #\/ #\C),
	C #<=>A,
	labeling(Vars).

*/

/* ostrvo 29

a, b, c. 
a: b laže
c: b ne laže ili ja lažem
c: a ne laže

rešenje: 

prolog:
ostrvo29(Vars):-
	Vars = [A,B,C],
	Vars in 0..1,
	A #<=> #\B,
	C #<=> (B #\/ #\C),
	C #<=>A,
	labeling(Vars).

*/

/* ostrvo 30
a, b, c, d. 
a: b ne laže ili c laže 
b: ako a ne laže, onda d laže
c: b i ja smo isti
d: c laže, a ne laže

rešenje: 

prolog:
ostrvo30(Vars):-
	Vars = [A,B,C,D],
	Vars in 0..1,
	A #<=> (B #\/ #\C),
	B #<=> (A #=> #\D),
	C #<=> (B <=> C),
	D #<=> (#\C => A)
	labeling(Vars).

*/

/* ostrvo 31
a, b, c, d, e. 

a: bar jedan od b i c govori istinu, ali ne oba
b: ako d ne laže, onda a laže
c: e i ja smo različiti
d: što se tiče a, b, c, tu ima dva lažova
e: b ne laže ako i samo ako a ne laže

rešenje: 

prolog:
ostrvo31(Vars):-
	Vars = [A,B,C,D,E],
	Vars in 0..1,
	A #<=> (B #\/ C),
	B #<=> (D #=> #\A),
	C #<=> (E #\<=> C),
	D #<=> (#\A #\/ #\B #\/ C) #\/ (#\A #\/ B #\/ #\C) #\/ (A #\/ #\B #\/ #\C),
	E #<=> (B #<=> A),
	labeling(Vars).

*/

/* ostrvo 32
a, b, c, d, e, f

a: b ne laže, c laže
b: ako a ne laže, ni d ne laže
c: d laže ili e laže
d: jedan od a i f ne laže
e: b i c su isti
f: e ne laže ako i samo ako a laže

rešenje:

prolog:
ostrvo32(Vars):-
	Vars = [A,B,C,D,E,F],
	Vars in 0..1,
	A #<=> (B #=> C),
	B #<=> (A,D),
	C #<=> (E #\<=> C),
	D #<=> (A #\/ B #\/ C),
	E #<=> (B = C),
	F #<=> (E <=> #\A),
	
	labeling(Vars).



*/

/* ostrvo 33
A, B, C, D, E, F, G, H, I, J

A: B i C nisu isti
B: D laže ako i samo ako A ne laže
C: E i F su isti
D: B laže ili G ne laže
E: A, B, C ne lažu
F: H ne laže ako i samo ako I laže
G: J laže ili A laže
H: C i F nisu isti
I: D ne laže, E laže
J: H laže ili G ne laže

rešenje: 

prolog:

ostrvo33(Vars):-
	Vars = [A,B,C,D,E,F,I,J],
	Vars in 0..1,
	A #<=> (B #\<=> C),
	B #<=> (#\D #<=> A),
	C #<=> (E #<=> F),
	D #<=> (#\B #\/ G),
	E #<=> (A #/\ B #/\ C),
	F #<=> (H #<=> #\I),
	G #<=> (#\J #\/ #\A),
	H #<=> (C #\<=> F)
	I #<=> (D #/\ #\E)
	J #<=> #\H #\/ G
	
	labeling(Vars).

*/
