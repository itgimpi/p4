ostrvo1(Vars) :-
Vars = [A],
A #<=> (#\A),
labeling(Vars).

/*nemoguce*/

ostrvo2(Vars) :-
Vars = [A],
A #<=> (A),
labeling(Vars).

/*nista ne moze da se zakljuci*/

ostrvo3(Vars) :-
Vars = [A],
labeling(Vars).

/*nista se ne moz zakljuci*/

ostrvo4(Vars) :-
Vars = [A,B],
A #<=> (A #/\ B),
labeling(Vars).

/*nista se ne moz zakljuci*/

ostrvo5(Vars) :-
Vars = [A,B],
A #<=> (#\A #/\ #\B),
labeling(Vars).

/*a laze b prica istinu*/

ostrvo6(Vars) :-
Vars = [A,B],
A #<=> (A #\/ B),
labeling(Vars).

/*nsita se ne moz zakljuci*/

ostrvo7(Vars) :-
Vars = [A,B],
A #<=> (#\A #\/ #\B),
labeling(Vars).

/*a prica istinu b laze*/

ostrvo8(Vars) :-
Vars = [A,B],
A #<=> (A #<=> B),
labeling(Vars).

/*B prica istinu*/

ostrvo9(Vars) :-
Vars = [A,B],
A #<=> (#\A #<=> B),
labeling(Vars).

/*B laze*/

ostrvo10(Vars) :-
Vars = [A,B],
A #<=> (A #/\ B),
labeling(Vars).

/*nista se ne moz zakljuci*/

ostrvo11(Vars) :-
Vars = [A,B],
A #<=> (A #/\ #\B),
labeling(Vars).

/*nista*/

ostrvo12(Vars) :-
Vars = [A,B],
A #<=> (#\A #/\ B),
labeling(Vars).

/*obojica lazu*/

ostrvo13(Vars) :-
Vars = [A,B],
A #<=> (#\A #/\ #\B),
labeling(Vars).

/*a laze b prica istinu*/

ostrvo14(Vars) :-
Vars = [A,B],
A #<=> (#\A #<=> B),
labeling(Vars).

/*b laze*/

ostrvo15(Vars) :-
Vars = [A,B],
A #<=> (#\A #<=> B),
labeling(Vars).

/*b laze*/

ostrvo16(Vars) :-
Vars = [A,B],
A #<=> (A #=> B),
labeling(Vars).

/*obojica pricaju istinu*/

ostrvo17(Vars) :-
Vars = [A,B],
A #<=> (A #=> #\B),
labeling(Vars).

/*a prica istinu b laze*/

ostrvo18(Vars) :-
Vars = [A,B],
A #<=> (#\A #=> B),
labeling(Vars).

/*nista*/

ostrvo19(Vars) :-
Vars = [A,B],
A #<=> (#\A #=> #\B),
labeling(Vars).

/*nista*/

ostrvo20(Vars) :-
Vars = [A,B,C],
A #<=> (A #\/ B #\/ C),
B #<=> (#\A #/\ #\B #/\ #\C),
C #<=> (#\A #/\ #\B),
labeling(Vars).

/*1,0,0*/

ostrvo21(Vars) :-
Vars = [A,B,C],
A #<=> (B),
B #<=> (#\A #/\ #\C),
labeling(Vars).

/*0,0,1*/

ostrvo22(Vars) :-
Vars = [A,B,C],
A #<=> (A #=> #\B),
B #<=> (B #/\ #\C),
labeling(Vars).

/*a prica istinu b laze, c ne znam*/

ostrvo23(Vars) :-
Vars = [A,B,C],
A #<=> (A),
B #<=> (A #=> #\B),
C #<=> (C #<=> A),
labeling(Vars).

/*nemoguce*/

ostrvo24(Vars) :-
Vars = [A,B,C],
B #<=> (#\A),
C #<=> (#\A #/\ #\B),
labeling(Vars).

/*c laze ostalo ne znamo*/

ostrvo25(Vars) :-
Vars = [A,B,C],
A #<=> (#\A #=> B),
B #<=> (B #<=> C),
C #<=> (#\A #/\ C),
labeling(Vars).

/*0,0,1*/

ostrvo26(Vars) :-
Vars = [A,B,C],
A #<=> (#\B #/\ #\A),
A #<=> (C),
labeling(Vars).

/*0,1,0*/

ostrvo27(Vars) :-
Vars = [A,B,C],
A #<=> (#\B #/\ #\A),
A #<=> (C),
labeling(Vars).

/*0,1,0*/

ostrvo28(Vars) :-
Vars = [A,B,C],
A #<=> (B),
C #<=> (B #\/ #\C),
C #<=> (A),
labeling(Vars).

/*1,1,1*/

ostrvo29(Vars) :-
Vars = [A,B,C],
A #<=> (#\B),
C #<=> (B #\/ #\C),
C #<=> (A),
labeling(Vars).

/*nemoguce*/

ostrvo30(Vars) :-
Vars = [A,B,C,D],
A #<=> (B #\/ #\C),
B #<=> (A #=> #\D),
C #<=> (B #<=> C),
D #<=> (#\C #/\ A),
labeling(Vars).

/*1,1,1,0*/

ostrvo31(Vars) :-
Vars = [A,B,C,D,E],
A #<=> ((B #/\ #\C) #\/ (#\B #/\ C)),
B #<=> (D #=> #\A),
C #<=> (#\C #<=> E),
D #<=> ((A #/\ #\B #/\ #\C) #\/ (#\A #/\ B #/\ #\C) #\/ (#\A #/\ #\B #/\ C)),
E #<=> (B #<=> A),
labeling(Vars).

/*0,1,1,0,0*/

/* ostrvo 32 original
a, b, c, d, e, f

a: b ne laže, c laže
b: ako a ne laže, ni d ne laže
c: d laže ili e laže
d: jedan od a i f ne laže
e: b i c su isti
f: e ne laže ako i samo ako a laže

rešenje: [0,1,1,0,1,0]

prolog:
ostrvo32(Vars) :-
    Vars = [A, B, C, D, E, F],
    Vars :: 0..1,
    A #<=> (B #/\ #\ C),
    B #<=> ( A #=> D ),
    C #<=> (#\ D #\/ #\ E),
    D #<=> (( #\A #/\ F) #\/ ( A #/\ #\ F)), 
    E #<=> ( B #<=> C ),
    F #<=> ( A #<=> E ),
    labeling(Vars).
*/

ostrvo33(Vars) :-
Vars = [A,B,C,D,E,F,G,H,I,J],
A #<=> (#\ (B #<=> C)),
B #<=> (#\D #<=> A),
C #<=> (E #<=> F),
D #<=> (#\B #\/ G),
E #<=> (A #/\ B #/\ C),
F #<=> (H #<=> #\I),
G #<=> (#\J #\/ #\A),
H #<=> #\ (C #<=> F),
I #<=> (D #/\ #\E),
J #<=> (#\H #\/ G),
labeling(Vars).

/*0,1,1,1,0,0,1,1,1,1*/